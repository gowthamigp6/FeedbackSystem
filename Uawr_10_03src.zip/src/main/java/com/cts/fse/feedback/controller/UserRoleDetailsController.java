package com.cts.fse.feedback.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.fse.feedback.bean.UserRoleDetails;
import com.cts.fse.feedback.jwt.message.response.JwtResponse;
import com.cts.fse.feedback.jwt.request.LoginForm;
import com.cts.fse.feedback.jwt.security.JwtProvider;
import com.cts.fse.feedback.service.UserRoleDetailsService;
/*
https://grokonez.com/spring-framework/spring-security/spring-

security-jwt-authentication-restapis-springboot-spring-mvc-

spring-security-spring-jpa-mysql*/

@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
@Controller
@RequestMapping(value={"/userDetails"})
public class UserRoleDetailsController {

	@Autowired
	private UserRoleDetailsService userRoleDetailsService;
	
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtProvider jwtProvider;
	
	@Autowired
    PasswordEncoder passwordEncoder;
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginForm loginRequest) {

		System.out.println("inside controller"+loginRequest);
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(),loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = jwtProvider.generateJwtToken(authentication);
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();            
		//check if this account is confirmed, ccode will be empty if 
		//user account is confirmed
		  UserRoleDetails user = userRoleDetailsService.findById(loginRequest.getUsername());
		  System.out.println("user login " + user);
		if(user!=null){
			return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(),user.getRole(),""));
		}else
		{
			return ResponseEntity.ok("{status: \"Confirmation Pending\"}");
		}
	}
	
	@GetMapping(value = "getLoginUser/{id}", headers="Accept=application/json",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserRoleDetails> getUserById(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        UserRoleDetails user = userRoleDetailsService.findById(id);
        System.out.println("Fetching User with id " + user);
        if (user == null) {
            return new ResponseEntity<UserRoleDetails>(HttpStatus.NOT_FOUND);
        }
        return  ResponseEntity.ok().body(user);
    }
    
    @PostMapping(value="/create")
	 public ResponseEntity<String>  createUser(@RequestBody UserRoleDetails user){
    	 userRoleDetailsService.createUser(user);	
    	return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	 }
 
	 @GetMapping(value="/get", headers="Accept=application/json")
	 public @ResponseBody Iterable<UserRoleDetails> getAllUser() {	 
	  return userRoleDetailsService.getUser();
	 }

	@PutMapping(value="/update")
	public ResponseEntity<String> updateUser(@RequestBody UserRoleDetails currentUser) {
		userRoleDetailsService.update(currentUser);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
	public ResponseEntity<UserRoleDetails> deleteUser(@PathVariable("id") Integer id){
		userRoleDetailsService.deleteUser(id);
		return new ResponseEntity<UserRoleDetails>(HttpStatus.NO_CONTENT);
	}
	
}