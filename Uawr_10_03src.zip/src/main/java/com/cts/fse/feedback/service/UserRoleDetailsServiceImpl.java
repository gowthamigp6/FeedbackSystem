package com.cts.fse.feedback.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.fse.feedback.bean.UserRoleDetails;
import com.cts.fse.feedback.jwt.security.UserPrinciple;
import com.cts.fse.feedback.repository.UserRoleDetailsRepository;



@Service
@Transactional
public class UserRoleDetailsServiceImpl implements UserRoleDetailsService {

	
	@Autowired
	private UserRoleDetailsRepository  userRoleDetailsRepository;

	@Override
	public UserRoleDetails createUser(UserRoleDetails user) {
		/*UserRoleDetails userRole=new UserRoleDetails();
		userRole.setAssociateId(user.getAssociateId());
		userRole.setAssociateName(user.getAssociateName());
		userRole.setRole(user.getRole());*/
		return userRoleDetailsRepository.save(user);
	}

	@Override
	public Iterable<UserRoleDetails> getUser() {
		return userRoleDetailsRepository.findAll();
	}

	@Override
	public UserRoleDetails findById(Integer associateId) {
		List<UserRoleDetails> userRoleDetails = userRoleDetailsRepository.getUserById(associateId);
		return userRoleDetails!=null ? userRoleDetails.get(0) : null;
	}

	@Override
	public UserRoleDetails update(UserRoleDetails user) {
		return userRoleDetailsRepository.save(user);
	}

	@Override
	public void deleteUser(Integer id) {
	  userRoleDetailsRepository.deleteById(id);
	}

	
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			
		System.out.println("------------------------------>");
		UserRoleDetails user = userRoleDetailsRepository.findById(Integer.parseInt(username)).orElseThrow(
				() -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
		System.out.println("------------------------------>"+user);
		System.out.println("------------------------------>"+UserPrinciple.build(user));
		return UserPrinciple.build(user);
	}
}