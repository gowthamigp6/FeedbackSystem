package com.cts.fse.feedback.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.web.bind.annotation.ResponseBody;

@Entity
public class UserRoleDetails  {

	@Id
    private Integer associateId;
    
    private String role;
    
    private String associateName;
    
	public String getAssociateName() {
		return associateName;
	}
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	public Integer getAssociateId() {
		return associateId;
	}
	public void setAssociateId(Integer associateId) {
		this.associateId = associateId;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserRoleDetails [associateId=" + associateId + ", role=" + role + ", associateName=" + associateName
				+ "]";
	}

	
}
