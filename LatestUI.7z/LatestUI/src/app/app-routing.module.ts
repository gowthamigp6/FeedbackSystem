import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FileUploadComponent} from './file-upload/file-upload.component';
import { HomeComponent } from './home/home.component';
import {HeaderComponent} from './header/header.component';
import {LoginComponent} from './login/login.component';
import {UserRoleComponent} from './user-role/user-role.component';
import {AddUserComponent} from './add-user/add-user.component';
import { ViewUserComponent } from './view-user/view-User.component';
import {FeedbackResponseComponent} from './feedback-response/feedback-response.component';
import { SendEmailComponent } from './send-email/send-email.component';

const routes: Routes = [
 
  {path: '',component: LoginComponent},
   {
    path: "header",
    component: HeaderComponent,
    children: [
      { path: "home", component: HomeComponent },
      { path: "fileUpload", component: FileUploadComponent },
      { path: "eventResponse", component: FeedbackResponseComponent },
      { path: "sendEmail", component: SendEmailComponent },
      { path: "userRole", component: UserRoleComponent,children:[
          {path: "addUser", component: AddUserComponent},
          {path: "viewUser", component: ViewUserComponent}
      ] },
     ]
  },
  {
    path: "userRole",
    component: UserRoleComponent,
    children:[
      {path: "addUser", component: AddUserComponent}
  ] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
