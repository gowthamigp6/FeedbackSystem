import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user.model';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserRoleService {

  private userUrl = window["apiBaseUrl"]+"userDetails";

  constructor(private http: HttpClient) { }

  getUsers(): Observable<User[]>{
	return this.http.get<User[]>(this.userUrl+"/get");
  }

     /** POST: add a new user to the server */
 addUser (user: User) {
  return this.http.post<User>(this.userUrl+"/create", user);
 
}

deleteUser (associateId: number){
  return this.http.delete(this.userUrl+"/"+ associateId);
}

updateUser(user : User){
  return this.http.put(this.userUrl+"/update",user);

}


}
