import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-response',
  templateUrl: './feedback-response.component.html',
  styleUrls: ['./feedback-response.component.css']
})
export class FeedbackResponseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
