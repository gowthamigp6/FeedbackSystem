import { Component, OnInit,ViewChild } from '@angular/core';
import { User } from '../model/user.model';
import {UserRoleService } from '../service/user-role.service';
import {MatPaginator, MatTableDataSource,MatDialog ,MatSort } from '@angular/material';
import { EditUserComponent } from '../edit-user/edit-user.component';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
   displayedColumns: string[] = ['associateId', 'associateName', 'role','Edit','delete'];
   dataSource = new MatTableDataSource<User>();
   //dataSource = new UserDataSource(this.userService);
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;

  constructor(private userService: UserRoleService,private dialog: MatDialog) { }
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getUsers();
  }
 
  public getUsers = () => {
    this.userService.getUsers()
    .subscribe(user => {
      this.dataSource.data = user as User[];
    })
  }

  
  redirectToEdit = (user: User) => {
    this.getUsers();
  }

  redirectToDelete = (id: number) => {
    this.userService.deleteUser(id).subscribe();
    this.loadData();
  }

   loadData() {
    this.dataSource = new MatTableDataSource<User>();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getUsers();
    
  }

  startEdit(user:User) {
    console.log("user"+user);
    let  dialogRef = this.dialog.open(EditUserComponent, {
      data: {user:user},
      width: '500px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.loadData();
      }
    });
  }
}
