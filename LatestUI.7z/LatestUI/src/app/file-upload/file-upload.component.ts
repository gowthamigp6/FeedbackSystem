import { Component, OnInit } from '@angular/core';
import { UploadFileService } from '../service/file-upload.service';
import { HttpResponse} from '@angular/common/http';



@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
 
  filesToUpload: Array<File> = [];
 
  constructor(private uploadService: UploadFileService) { }
 
  ngOnInit() {
  }
 
  upload() {
    const formData: any = new FormData();
    const files: Array<File> = this.filesToUpload;
    console.log(files);
    for(let i =0; i < files.length; i++){
        formData.append("file", files[i]);
    }
    this.uploadService.save(formData).subscribe(event =>{
      if(event instanceof HttpResponse) {
        console.log('File Uploaded successfully');
      }
    });
    console.log('form data variable :   '+ formData.toString());
}

fileChangeEvent(fileInput: any) {
    this.filesToUpload = <Array<File>>fileInput.target.files;
    //this.product.photo = fileInput.target.files[0]['name'];
}
}
