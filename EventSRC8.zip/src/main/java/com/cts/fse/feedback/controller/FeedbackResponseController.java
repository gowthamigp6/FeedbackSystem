package com.cts.fse.feedback.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.fse.feedback.dto.EventResponseDTO;
import com.cts.fse.feedback.service.FeedbackResponseService;

@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
@RestController
@RequestMapping(value={"/feedbackresponse"})
public class FeedbackResponseController {

	   /* @Autowired
	    private JavaMailSender sender;*/
	    
	    @Autowired
	    private FeedbackResponseService feedbackResponseService;

	   /* @RequestMapping("/sendMail")
	    public String sendMail() {
	        MimeMessage message = sender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);

	        try {
	            helper.setTo("gow.cute@gmail.com");
	            helper.setText("Greetings :)");
	            helper.setSubject("Mail From Spring Boot");
	        } catch (MessagingException e) {
	            e.printStackTrace();
	            return "Error while sending mail ..";
	        }
	        sender.send(message);
	        return "Mail Sent Success!";
	    }*/
	    
	    @GetMapping(value="/eventfeedbackResponse/{id}", headers="Accept=application/json")
		public String getEventListEmployee(@PathVariable("id") int associateId) {
			return feedbackResponseService.getEventList(associateId);
		}
	    
	    @PutMapping(value="/eventfeedbackResponse/{id}", headers="Accept=application/json")
	    public String saveEventFeedbackResponse(@PathVariable("id") String associateId,@RequestBody List<EventResponseDTO> responseDetails) {
	    	for(EventResponseDTO eventResponseDTO : responseDetails) {
	    		System.out.println(eventResponseDTO);
	    	}
	    	System.out.println(associateId);
	    	return "ok";
	    }
	  
}
