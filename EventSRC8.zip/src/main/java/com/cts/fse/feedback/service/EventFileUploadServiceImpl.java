package com.cts.fse.feedback.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.cts.fse.feedback.bean.EventEmployeeInfo;
import com.cts.fse.feedback.bean.EventSummaryDetails;
import com.cts.fse.feedback.repository.EventEmployeeInfoRepository;
import com.cts.fse.feedback.repository.EventSummaryDetailsRepository;
import com.cts.fse.feedback.repository.FeedbackDetailsRepository;
import com.cts.fse.feedback.utils.FeedbackConstants;
import com.cts.fse.feedback.utils.Utils;



@Service
@Transactional
public class EventFileUploadServiceImpl implements EventFileUploadService {

	@Autowired
	private EventEmployeeInfoRepository  eventEmployeeInfoRepository;
	
	@Autowired
	private EventSummaryDetailsRepository eventSummaryDetailsRepository;
	
	@Autowired
	private FeedbackDetailsRepository feedbackDetailsRepository;
	
	@Autowired
	private JavaMailSender sender;
	
	private String sendMailToAssociates(List<EventEmployeeInfo> eventEmpList,String eventStatus) {
	        MimeMessage message = sender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);
	        try {
	        	String emailTemplate = feedbackDetailsRepository.getEmailTemplate(eventStatus);
	        	for(EventEmployeeInfo eventEmployeeInfo : eventEmpList){
	        		helper.setTo("gow.cute@gmail.com");
	        		helper.setText(emailTemplate);
	        		helper.setSubject("Feedback Survey for Event "+eventEmployeeInfo.getEventEmployeeIdentity().getEventId());
	        		sender.send(message);
	        		eventEmployeeInfo.setEmailSendDate(new Date());
	        		eventEmployeeInfo.setEmailCount(1);
	        		eventEmployeeInfoRepository.save(eventEmployeeInfo);
	        	}
	        } catch (MessagingException e) {
	            e.printStackTrace();
	            return "Error while sending mail ..";
	        }
	        return "Mail Sent Success!";
	}
	
	@Override
	public void saveEventSummaryDetails(FileInputStream inputStream) {
		List<EventSummaryDetails> eventSummaryDetails =null;
		try {
			eventSummaryDetails = Utils.parseExcelFileToBeans(inputStream,FeedbackConstants.EVENT_SUMMARY_MAPPER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(eventSummaryDetails);
		eventSummaryDetailsRepository.saveAll(eventSummaryDetails);
	}
	
	@Override
	public void saveEventFileUpload(FileInputStream inputStream,String eventStatus) {
		List<EventEmployeeInfo> eventEmployeeInfoList =null;
		try {
			String xlsReader = eventStatus.equalsIgnoreCase(FeedbackConstants.UNREGISTERED) ||  eventStatus.equalsIgnoreCase(FeedbackConstants.NOT_ATTENDED)
					 ? FeedbackConstants.EVENT_EMP_LIST :FeedbackConstants.EVENT_EMPINFO_MAPPER;
			eventEmployeeInfoList = Utils.parseExcelFileToBeans(inputStream,xlsReader);
			for(EventEmployeeInfo eventEmployeeInfo : eventEmployeeInfoList) {
				eventEmployeeInfo.setEventStatus(eventStatus);
			}
			List<EventEmployeeInfo> eventEmpList = (List<EventEmployeeInfo>) eventEmployeeInfoRepository.saveAll(eventEmployeeInfoList);
			sendMailToAssociates(eventEmpList,eventStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(eventEmployeeInfoList);
	}
	
	
	@Override
	public void executeInputEventFile() {
		 try {
		 File directory = new File ("C:\\Users\\temp");
		 if(directory.isDirectory()) {
			 for (File file : directory.listFiles()) {
				 String fileName=file.getName();
				 FileInputStream inputStream=new FileInputStream(file.getAbsolutePath());
				 if(fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
					 if(fileName.startsWith("OutReach Event Information")) {
						 saveEventFileUpload(inputStream,FeedbackConstants.PARTICIPATED);
					 }else  if(fileName.startsWith("Outreach Events Summary")) {
						 saveEventSummaryDetails(inputStream);
					 }else  if(fileName.startsWith("Volunteer_Enrollment Details_Not_Attend")) {
						 saveEventFileUpload(inputStream,FeedbackConstants.NOT_ATTENDED);
					 }else {
						 saveEventFileUpload(inputStream,FeedbackConstants.UNREGISTERED);
					 }
				 }
				 if(inputStream!=null) {
					 inputStream.close();
				 }
			 }
		 	}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
		
	}

}
