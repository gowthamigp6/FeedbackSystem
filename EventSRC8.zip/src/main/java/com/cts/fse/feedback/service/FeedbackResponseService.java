package com.cts.fse.feedback.service;

public interface FeedbackResponseService {

	public String getEventList(int associateId);
	
}
