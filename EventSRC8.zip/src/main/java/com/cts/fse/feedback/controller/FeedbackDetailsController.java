package com.cts.fse.feedback.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.fse.feedback.bean.FeedbackDetails;
import com.cts.fse.feedback.service.FeedBackDetaillsService;

@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
@Controller
@RequestMapping(value={"/feedBackDetails"})
public class FeedbackDetailsController {

	 @Autowired
	 private FeedBackDetaillsService feedBackService;
	

	 @GetMapping(value="/get", headers="Accept=application/json")
	 public @ResponseBody Iterable<FeedbackDetails> getAll() {	 
	  return feedBackService.getFeedBackDetails();
	 }
	 
     @PostMapping(value="/create")
	 public ResponseEntity<String>  create(@RequestBody FeedbackDetails feedbackDetails){
    	feedBackService.createFeedBackQuestion(feedbackDetails);	
    	return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	 }
 
	@PutMapping(value="/update")
	public ResponseEntity<String> update(@RequestBody FeedbackDetails feedbackDetails) {
		feedBackService.update(feedbackDetails);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
	public ResponseEntity<FeedbackDetails> delete(@PathVariable("id") Integer id){
		feedBackService.deleteFeedBack(id);
		return new ResponseEntity<FeedbackDetails>(HttpStatus.NO_CONTENT);
	}

    @GetMapping(value="getDetails/{eventStatus}", headers="Accept=application/json")
    public  @ResponseBody Iterable<FeedbackDetails> getFeedbackQuestion(@PathVariable("eventStatus") String eventStatus) {
		return feedBackService.getFeedBackQuestion(eventStatus);
    }
    
}
