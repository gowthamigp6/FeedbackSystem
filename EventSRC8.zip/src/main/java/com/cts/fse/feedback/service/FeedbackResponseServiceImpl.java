package com.cts.fse.feedback.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.fse.feedback.bean.EventEmployeeInfo;
import com.cts.fse.feedback.repository.EventEmployeeInfoRepository;

@Service
@Transactional
public class FeedbackResponseServiceImpl implements FeedbackResponseService {

	@Autowired
	private EventEmployeeInfoRepository eventEmployeeInfoRepository;
	
	@Override
	public String getEventList(int associateId) {
		return eventEmployeeInfoRepository.getEventEmpList(associateId);
	}

}
