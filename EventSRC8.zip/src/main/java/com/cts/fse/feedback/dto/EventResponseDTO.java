package com.cts.fse.feedback.dto;

public class EventResponseDTO {

	private int id;
	
	private String feedbackResponse;
	
	private boolean selected;
	
	private String smileyValue;
	
	

	public String getSmileyValue() {
		return smileyValue;
	}

	public void setSmileyValue(String smileyValue) {
		this.smileyValue = smileyValue;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFeedbackResponse() {
		return feedbackResponse;
	}

	public void setFeedbackResponse(String feedbackResponse) {
		this.feedbackResponse = feedbackResponse;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public String toString() {
		return "EventResponseDTO [id=" + id + ", feedbackResponse=" + feedbackResponse + ", selected=" + selected
				+ ", smileyValue=" + smileyValue + "]";
	}

	
	
	
}
