package com.cts.fse.feedback.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.fse.feedback.bean.EventEmployeeIdentity;
import com.cts.fse.feedback.bean.EventEmployeeInfo;

@Repository
public interface EventEmployeeInfoRepository extends CrudRepository<EventEmployeeInfo, EventEmployeeIdentity>
{
	
	@Query("select emp.eventStatus from EventEmployeeInfo emp where emp.eventEmployeeIdentity.associateId= :associateId"
			+ " and emp.emailSendDate=(select max(emp.emailSendDate) from EventEmployeeInfo  emp where "
			+ "emp.eventEmployeeIdentity.associateId= :associateId)")
	String getEventEmpList(@Param("associateId") int associateId);
	
}
