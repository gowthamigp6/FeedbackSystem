package com.cts.fse.feedback.service;

import java.io.FileInputStream;

public interface EventFileUploadService {
	
	public void saveEventFileUpload(FileInputStream inputStream,String eventStatus);
	public void saveEventSummaryDetails(FileInputStream inputStream);
	public void executeInputEventFile();
	
}
