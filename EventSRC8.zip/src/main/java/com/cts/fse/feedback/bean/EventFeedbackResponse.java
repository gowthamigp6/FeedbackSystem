package com.cts.fse.feedback.bean;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class EventFeedbackResponse implements Serializable {
	
	@EmbeddedId
	private EventFeedbackResponseIdentity eventFeedbackResponseIdentity;
	
    private String feedbackResponse;
   
    private String status;
    
    @ManyToOne
    @JoinColumns({@JoinColumn(name="associateId",referencedColumnName="associateId",insertable=false,updatable=false),
    			  @JoinColumn(name="eventId",referencedColumnName="eventId",insertable=false,updatable=false)})
    private EventEmployeeInfo eventEmployeeInfo;

	public String getFeedbackResponse() {
		return feedbackResponse;
	}
	public void setFeedbackResponse(String feedbackResponse) {
		this.feedbackResponse = feedbackResponse;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public EventFeedbackResponseIdentity getEventFeedbackResponseIdentity() {
		return eventFeedbackResponseIdentity;
	}
	public void setEventFeedbackResponseIdentity(EventFeedbackResponseIdentity eventFeedbackResponseIdentity) {
		this.eventFeedbackResponseIdentity = eventFeedbackResponseIdentity;
	}
	public EventEmployeeInfo getEventEmployeeInfo() {
		return eventEmployeeInfo;
	}
	public void setEventEmployeeInfo(EventEmployeeInfo eventEmployeeInfo) {
		this.eventEmployeeInfo = eventEmployeeInfo;
	}
	
    
    
    
}
