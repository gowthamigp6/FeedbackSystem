package com.cts.fse.feedback.service;

import com.cts.fse.feedback.bean.FeedbackDetails;

public interface FeedBackDetaillsService {
	public FeedbackDetails createFeedBackQuestion(FeedbackDetails feedbackDetails);
	public Iterable<FeedbackDetails> getFeedBackDetails();
	public FeedbackDetails update(FeedbackDetails feedbackDetails);
	public void deleteFeedBack(Integer id);
	public Iterable<FeedbackDetails> getFeedBackQuestion(String eventStatus);
}

