package com.cts.fse.feedback.controller;

import java.io.FileInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.cts.fse.feedback.service.EventFileUploadService;
import com.cts.fse.feedback.utils.FeedbackConstants;


@CrossOrigin
@Controller
@RequestMapping(value={"/eventFileUpload"})
public class EventFileUploadController {

	@Autowired
	private EventFileUploadService eventFileUploadService;
	
	 @CrossOrigin(origins = "http://localhost:4200") // Call  from Local Angualar
	 @PostMapping("/fileUpload")
	 public ResponseEntity < String > handleFileUpload(@RequestParam("file") MultipartFile[] files) {
	  String message = "";
	  try {
		  for(MultipartFile file : files) {
			  String fileName = file.getName();
			  FileInputStream inputStream=(FileInputStream) file.getInputStream();
			  if(fileName.startsWith("OutReach Event Information")) {
				  eventFileUploadService.saveEventFileUpload(inputStream,FeedbackConstants.PARTICIPATED);
				 }else  if(fileName.startsWith("Outreach Events Summary")) {
					 eventFileUploadService.saveEventSummaryDetails(inputStream);
				 }else  if(fileName.startsWith("Volunteer_Enrollment Details_Not_Attend")) {
					 eventFileUploadService.saveEventFileUpload(inputStream,FeedbackConstants.NOT_ATTENDED);
				 }else {
					 eventFileUploadService.saveEventFileUpload(inputStream,FeedbackConstants.UNREGISTERED);
				 }
			  	 if(inputStream!=null) {
					 inputStream.close();
				 }
			}
	   message = "You successfully uploaded ";
	   return ResponseEntity.status(HttpStatus.OK).body(message);
	  } catch (Exception e) {
	   message = "Fail to upload Profile Picture";
	   return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
	  }
	 }
}