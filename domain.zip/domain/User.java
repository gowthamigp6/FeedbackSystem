package com.cts.ddd.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;


@Entity
public class User {

	@Id
	private String userId;
	private String firstName;
	private String lastName;
	private String role;
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="addressId",referencedColumnName="addressId",
	    insertable=false,updatable=false)})
	private ContactInformation address;

	
}
