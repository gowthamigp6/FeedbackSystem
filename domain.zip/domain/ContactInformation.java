package com.cts.ddd.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

@Entity
public class ContactInformation {

	@Id
	@GeneratedValue
	private String addressId;
	
	private String streetName;
	private String doorNo;
	private String plotNo;
	private String city;
	private String pinCode;
	private String emailId;
	private String telephoneNo;
//	
//	@OneToOne
//	@JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
//    insertable=false,updatable=false)})
//	private User user;
}
