package com.cts.ddd.domain;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

@Entity
public class EmployeeRegistration {

	@Id
    private String vehicleNo;

    private String vehicleType;

    private Integer seater;
    
    private String fromLocation;
    
    private String toLocation;
    
    private BigDecimal travelCost;
    
	@OneToOne
	@JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
    insertable=false,updatable=false)})
	private User user;

    
}