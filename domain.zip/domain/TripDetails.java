package com.cts.ddd.domain;

import java.sql.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;



@Entity
public class TripDetails {


	@EmbeddedId
    private TripDetailsIdentity tripDetailsIdentity;
    
    private String travelTime;


    private String travelStatus;
    
    @ManyToOne
    @JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
    insertable=false,updatable=false)})
    private User user;
    
    @ManyToOne
    @JoinColumns({@JoinColumn(name="vehicleNo",referencedColumnName="vehicleNo",
    insertable=false,updatable=false)})
    private EmployeeRegistration employeeRegistration;
}
