package com.cts.ddd.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
//import javax.validation.constraints.NotNull;

@Embeddable
public class TripDetailsIdentity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//@NotNull
	@Column(length=50)
    private String userId;
	
	//@NotNull
	@Column(length=15)
    private String vehicleNo;

    private Date travelDate;
}
