import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule,ReactiveFormsModule, FormGroup,FormBuilder, Validators } from '@angular/forms';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { CdkTableModule} from '@angular/cdk/table';
import {DataSource} from '@angular/cdk/table';

export interface PeriodicElement {
  id: number;
  name: string;
  role: string;
  status:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, name: 'Hydrogen', role: 'Admin', status: 'ACTIVE'},
  {id: 2, name: 'Helium', role: 'Admin', status: 'ACTIVE'},
  {id: 3, name: 'Lithium', role: 'Admin', status: 'ACTIVE'},
  {id: 4, name: 'Beryllium', role: 'Admin', status: 'ACTIVE'},
  {id: 5, name: 'Boron', role: 'Admin', status: 'ACTIVE'},
];
@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private formModule : FormsModule,
    private router: Router
  ) { }

  ngOnInit() {
  }
  displayedColumns: string[] = ['id', 'name', 'role', 'status'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
}
