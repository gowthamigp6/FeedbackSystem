import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule,ReactiveFormsModule, FormGroup,FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  userRoleForm: FormGroup;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private formModule : FormsModule,
    private router: Router
  ) { }

  

  ngOnInit() {
    this.userRoleForm = this.formBuilder.group({
      associateId: ['', Validators.required],
      role: ['', Validators.required],
      associateName: ['', Validators.required]
    });
  }

  onSubmit() {
   
    this.submitted = true;

        // stop here if form is invalid
        if (this.userRoleForm.invalid) {
            return;
        }else{
          this.router.navigate(['/viewUser']);
        }
      
          
     
  }
}