import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClient, HttpRequest, HttpEvent} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from "@angular/router";
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { NavigationComponent } from './navigation/navigation.component';
import { UploadFileService } from './service/file-upload.service';
import { UserRoleComponent } from './user-role/user-role.component';
import { AddUserComponent } from './add-user/add-user.component';
import { MatTabsModule } from '@angular/material';
import { CdkTableModule} from '@angular/cdk/table';
import {DataSource} from '@angular/cdk/table';
import {MatTableModule } from '@angular/material';
import { ViewUserComponent } from './view-user/view-User.component';
import { FeedbackResponseComponent } from './feedback-response/feedback-response.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    FooterComponent,
    FileUploadComponent,
    NavigationComponent,
    UserRoleComponent,
    AddUserComponent,
    ViewUserComponent,
    FeedbackResponseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule,
    MatTabsModule,
    CdkTableModule,
    MatTableModule,
    HttpClientModule
  ],
  providers: [UploadFileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
