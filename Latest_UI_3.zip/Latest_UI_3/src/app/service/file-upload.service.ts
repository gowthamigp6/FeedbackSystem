import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable()
export class UploadFileService {
 constructor (private http: HttpClient){}
    save(data: FormData): Observable<HttpEvent<{}>> {
        const req=new HttpRequest("POST","http://localhost:8080/eventFileUpload/fileUpload",data,{
            reportProgress:true,
            responseType:'text'
        }
        );
        return this.http.request(req);
      }
}