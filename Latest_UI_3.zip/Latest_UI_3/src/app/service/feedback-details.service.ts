import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import {FeedBackDetails} from '../model/feedback.model';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class FeedBackService {

  private url = window["apiBaseUrl"]+"feedBackDetails";

  constructor(private http: HttpClient) { }

  get(): Observable<FeedBackDetails[]>{
	return this.http.get<FeedBackDetails[]>(this.url+"/get");
  }

     /** POST: add a new user to the server */
 add(user: FeedBackDetails) : Observable<FeedBackDetails> {
  const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});
  return this.http.post<FeedBackDetails>(this.url+"/create", JSON.stringify(user), {headers: headers});
 
}

delete(id: number){
  return this.http.delete(this.url+"/"+ id).subscribe(
    data  => {console.log("delete Request is successful ", data);})
}


update(user : FeedBackDetails){
    const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});

    this.http.put(this.url+"/update", JSON.stringify(user), {headers: headers}).subscribe(() => user);
}



}
