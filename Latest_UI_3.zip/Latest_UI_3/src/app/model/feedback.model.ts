export interface FeedBackDetails{
    id: number;
	feedBackDesc: string;
	status: string; 
	emailTemplate:string;
}