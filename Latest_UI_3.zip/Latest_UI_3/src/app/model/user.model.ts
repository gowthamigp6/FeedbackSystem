export interface User{

    associateId: number;
	associateName: string;
	role: string; 
}