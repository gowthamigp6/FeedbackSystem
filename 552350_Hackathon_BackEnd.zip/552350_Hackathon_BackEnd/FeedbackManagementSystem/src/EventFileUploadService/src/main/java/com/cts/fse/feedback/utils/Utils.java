package com.cts.fse.feedback.utils;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jxls.reader.ReaderBuilder;
import org.jxls.reader.XLSReader;


public class Utils {
	/**
	* Parses an excel file into a list of beans.
	*
	* @param <T> the type of the bean
	* @param xlsFile the excel data file to parse
	* @param jxlsConfigFile the jxls config file describing how to map rows to beans
	* @return the list of beans or an empty list there are none
	* @throws Exception if there is a problem parsing the file
	*/
	public static <T> List<T> parseExcelFileToBeans(final FileInputStream xlsFile,
	                                                final String jxlsConfigFileName) {
		
		
		InputStream file2 = null;
		try {
			 file2 = Utils.class.getResourceAsStream("/"+jxlsConfigFileName);
			 System.out.println(file2.toString()+"------------"+file2.read());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("------"+e1.getMessage());
		}
		
		
	  final List<T> result = new ArrayList<>();
	  try {
	
	  //ClassLoader classLoader = ClassLoader.getSystemClassLoader();
	 
	  //File jxlsConfigFile = new File(classLoader.getResource(jxlsConfigFileName).getFile());
	  final XLSReader xlsReader = ReaderBuilder.buildFromXML(Utils.class.getResourceAsStream("/"+jxlsConfigFileName));
	  final Map<String, Object> beans = new HashMap();
	  beans.put("result", result);
	  InputStream inputStream = new BufferedInputStream(xlsFile);
	  xlsReader.read(inputStream, beans);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  
	  System.out.println(result);
	  return result;
	}
	
}
