package com.cts.fse.feedback.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class EventEmployeeInfo implements Serializable{

	@EmbeddedId
    private EventEmployeeIdentity eventEmployeeIdentity;
    
    private String associateName;
    
    private String bu;
    
    @Column(nullable = false)
    private String eventStatus;
  
    private BigDecimal volunteerhrs;
    
    private BigDecimal travelhrs;
    
    private BigDecimal livesImpacted;
    
    private String category;
    
    public EventEmployeeInfo() {
    	this.eventEmployeeIdentity = new EventEmployeeIdentity();
    }
    
	public EventEmployeeInfo(EventEmployeeIdentity eventEmployeeIdentity) {
		super();
		this.eventEmployeeIdentity = eventEmployeeIdentity;
	}
	public EventEmployeeIdentity getEventEmployeeIdentity() {
		return eventEmployeeIdentity;
	}
	public void setEventEmployeeIdentity(EventEmployeeIdentity eventEmployeeIdentity) {
		this.eventEmployeeIdentity = eventEmployeeIdentity;
	}
	public String getAssociateName() {
		return associateName;
	}
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public BigDecimal getVolunteerhrs() {
		return volunteerhrs;
	}
	public void setVolunteerhrs(BigDecimal volunteerhrs) {
		this.volunteerhrs = volunteerhrs;
	}
	public BigDecimal getTravelhrs() {
		return travelhrs;
	}
	public void setTravelhrs(BigDecimal travelhrs) {
		this.travelhrs = travelhrs;
	}
	public BigDecimal getLivesImpacted() {
		return livesImpacted;
	}
	public void setLivesImpacted(BigDecimal livesImpacted) {
		this.livesImpacted = livesImpacted;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "EventEmployeeInfo [eventEmployeeIdentity=" + eventEmployeeIdentity + ", associateName=" + associateName
				+ ", bu=" + bu + ", eventStatus=" + eventStatus + ", volunteerhrs=" + volunteerhrs + ", travelhrs="
				+ travelhrs + ", livesImpacted=" + livesImpacted + ", category=" + category + "]";
	}
	
	
}
