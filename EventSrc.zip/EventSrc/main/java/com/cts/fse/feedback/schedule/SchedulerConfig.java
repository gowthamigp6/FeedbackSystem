package com.cts.fse.feedback.schedule;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

@Configuration
public class SchedulerConfig {

	@Bean
	public JobDetail jobDetail() {
	    return JobBuilder.newJob().ofType(EventFileUploadJob.class)
	      .storeDurably()
	      .withIdentity("Qrtz_Job_Detail")  
	      .withDescription("Invoke Sample Job service...")
	      .build();
	}
	
	/*@Bean
	public JobDetailFactoryBean jobDetail() {
	    JobDetailFactoryBean jobDetailFactory = new JobDetailFactoryBean();
	    jobDetailFactory.setJobClass(EventFileUploadJob.class);
	    jobDetailFactory.setDescription("Invoke Sample Job service...");
	    jobDetailFactory.setDurability(true);
	    return jobDetailFactory;
	}*/
	
	@Bean
	public SimpleTriggerFactoryBean trigger() {
	    SimpleTriggerFactoryBean trigger = new SimpleTriggerFactoryBean();
	    trigger.setJobDetail(jobDetail());
	    trigger.setRepeatInterval(1000000);
	    trigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
	    return trigger;
	}
	
	
	
	
	
	/*@Bean
	public SimpleTriggerFactoryBean trigger(JobDetail job) {
	    SimpleTriggerFactoryBean trigger = new SimpleTriggerFactoryBean();
	    trigger.setJobDetail(job);
	    trigger.setRepeatInterval(3600000);
	    trigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
	    return trigger;
	}*/
	
	/*@Bean
	public Scheduler scheduler() {
	    StdSchedulerFactory factory = new StdSchedulerFactory();
	    factory.initialize(new ClassPathResource("quartz.properties").getInputStream());
	 
	    Scheduler scheduler = factory.getScheduler();
	    scheduler.setJobFactory(springBeanJobFactory());
	    scheduler.scheduleJob(jobDetail(), trigger(jobDetail()));
	 
	    scheduler.start();
	    return scheduler;
	}*/
}
