package com.cts.fse.feedback.schedule;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.fse.feedback.service.EventFileUploadService;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class EventFileUploadJob implements Job {
 
    @Autowired
    private EventFileUploadService fileUploadJobService;
 
    public void execute(JobExecutionContext context) throws JobExecutionException {
    	System.out.println("Candidjava welcomes simple job");
    	//fileUploadJobService.executeInputEventFile();
    }

}
