package com.cts.fse.feedback.service;

import com.cts.fse.feedback.bean.FeedBackDetails;

public interface FeedBackDetaillsService {
	public FeedBackDetails createFeedBackQuestion(FeedBackDetails feedbackDetails);
	public Iterable<FeedBackDetails> getFeedBackDetails();
	public FeedBackDetails update(FeedBackDetails feedbackDetails);
	public void deleteFeedBack(Integer id);
}
