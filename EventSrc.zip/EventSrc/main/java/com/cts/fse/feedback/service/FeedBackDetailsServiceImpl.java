package com.cts.fse.feedback.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.fse.feedback.bean.FeedBackDetails;
import com.cts.fse.feedback.repository.FeedbackDetailsRepository;

@Service
@Transactional
public class FeedBackDetailsServiceImpl implements FeedBackDetaillsService{

	@Autowired
	private FeedbackDetailsRepository  feedbackDetailsRepository;
	
	@Override
	public FeedBackDetails createFeedBackQuestion(FeedBackDetails feedbackDetails) {
		return feedbackDetailsRepository.save(feedbackDetails);
	}

	@Override
	public Iterable<FeedBackDetails> getFeedBackDetails() {
		return feedbackDetailsRepository.findAll();
	}

	@Override
	public FeedBackDetails update(FeedBackDetails feedbackDetails) {
		return feedbackDetailsRepository.save(feedbackDetails);
	}

	@Override
	public void deleteFeedBack(Integer id) {
		feedbackDetailsRepository.deleteById(id);
	}

}
