package com.cts.fse.feedback.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.fse.feedback.bean.EventEmployeeInfo;
import com.cts.fse.feedback.bean.EventSummaryDetails;
import com.cts.fse.feedback.repository.EventEmployeeInfoRepository;
import com.cts.fse.feedback.repository.EventSummaryDetailsRepository;
import com.cts.fse.feedback.utils.FeedbackConstants;
import com.cts.fse.feedback.utils.Utils;



@Service
@Transactional
public class EventFileUploadServiceImpl implements EventFileUploadService {

	@Autowired
	private EventEmployeeInfoRepository  eventEmployeeInfoRepository;
	
	@Autowired
	private EventSummaryDetailsRepository eventSummaryDetailsRepository;
	
	
	@Override
	public void saveEventSummaryDetails(FileInputStream inputStream) {
		List<EventSummaryDetails> eventSummaryDetails =null;
		try {
			eventSummaryDetails = Utils.parseExcelFileToBeans(inputStream,FeedbackConstants.EVENT_SUMMARY_MAPPER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(eventSummaryDetails);
		eventSummaryDetailsRepository.saveAll(eventSummaryDetails);
	}
	
	@Override
	public void saveEventFileUpload(FileInputStream inputStream,String eventStatus) {
		List<EventEmployeeInfo> eventEmployeeInfoList =null;
		try {
			String xlsReader = eventStatus.equalsIgnoreCase(FeedbackConstants.UNREGISTERED) ||  eventStatus.equalsIgnoreCase(FeedbackConstants.NOT_ATTENDED)
					 ? FeedbackConstants.EVENT_EMP_LIST :FeedbackConstants.EVENT_EMPINFO_MAPPER;
			eventEmployeeInfoList = Utils.parseExcelFileToBeans(inputStream,xlsReader);
			for(EventEmployeeInfo eventEmployeeInfo : eventEmployeeInfoList) {
				eventEmployeeInfo.setEventStatus(eventStatus);
			}
			eventEmployeeInfoRepository.saveAll(eventEmployeeInfoList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(eventEmployeeInfoList);
	}
	
	
	@Override
	public void executeInputEventFile() {
		 try {
		 File directory = new File ("C:\\Users\\temp");
		 if(directory.isDirectory()) {
			 for (File file : directory.listFiles()) {
				 String fileName=file.getName();
				 FileInputStream inputStream=new FileInputStream(file.getAbsolutePath());
				 if(fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
					 if(fileName.startsWith("OutReach Event Information")) {
						 saveEventFileUpload(inputStream,FeedbackConstants.PARTICIPATED);
					 }else  if(fileName.startsWith("Outreach Events Summary")) {
						 saveEventSummaryDetails(inputStream);
					 }else  if(fileName.startsWith("Volunteer_Enrollment Details_Not_Attend")) {
						 saveEventFileUpload(inputStream,FeedbackConstants.NOT_ATTENDED);
					 }else {
						 saveEventFileUpload(inputStream,FeedbackConstants.UNREGISTERED);
					 }
				 }
				 if(inputStream!=null) {
					 inputStream.close();
				 }
			 }
		 	}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
		
	}

}
