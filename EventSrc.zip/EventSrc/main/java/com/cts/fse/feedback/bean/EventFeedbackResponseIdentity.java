package com.cts.fse.feedback.bean;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.validation.constraints.NotNull;

@Embeddable
public class EventFeedbackResponseIdentity implements Serializable {

	@NotNull
    private Integer associateId;
	
	@NotNull
    private Integer eventId;
	
	@NotNull
    private Integer feedbackId;

	

	public Integer getAssociateId() {
		return associateId;
	}

	public void setAssociateId(Integer associateId) {
		this.associateId = associateId;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Integer getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}
	
	
}
