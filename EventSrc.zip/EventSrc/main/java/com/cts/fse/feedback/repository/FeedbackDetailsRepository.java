package com.cts.fse.feedback.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cts.fse.feedback.bean.FeedBackDetails;

@Repository
public interface FeedbackDetailsRepository extends CrudRepository<FeedBackDetails, Integer> {

}
