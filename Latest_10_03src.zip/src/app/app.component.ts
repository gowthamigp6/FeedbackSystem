import { Component } from '@angular/core';
import { User } from './model/user.model';
import { Router } from '@angular/router';
import {AuthenticationService } from './service/authentication.service';
import { TokenStorageService } from './auth/token-storage.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'OutReach FeedBack System';
  private roles: string[];
  private authority: string;

  constructor(private tokenStorage: TokenStorageService) { }

  ngOnInit() {
   console.log("token in app"+this.tokenStorage.getToken)
  }
}