export interface FeedBackDetails{
    id: number;
	feedBackDesc: string;
	status: string; 
	emailTemplate:string;
	inputType:string;
	selected:boolean;
	feedbackResponse:String;
	smileyValue:string;
}