import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import {UserRoleService } from '../service/user-role.service';
import { User } from '../model/user.model';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  userRoleForm: FormGroup;
  user: Object ={};
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private userService: UserRoleService
  ) { }

  ngOnInit() {
    this.userRoleForm = this.formBuilder.group({
      associateId: ['', Validators.required],
      role: ['', Validators.required],
      associateName: ['', Validators.required]
    });
  }

  addUser(user: User): void {
   
    this.userService.addUser(user).subscribe(data => {alert("User created successfulyy");});
  }

  
  onSubmit(user: User) {
   
    this.submitted = true;

        // stop here if form is invalid
        if (this.userRoleForm.invalid) {
            return;
        }else{
          this.addUser(user);
        }
  }

  
}