package com.cts.fse.feedback;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cts.fse.feedback.service.FileWatchServiceImpl;

@SpringBootApplication
public class EventFileUploadServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventFileUploadServiceApplication.class, args);
		/*Path dir = Paths.get("C:\\Users\\temp\\");
        try {
			new FileWatchServiceImpl().processEvents();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}
