package com.cts.fse.feedback;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.fse.feedback.service.FileWatchServiceImpl;


@Configuration
public class FileWatcherConfiguration {

	@Bean
    public FileWatchServiceImpl init() {
		return new FileWatchServiceImpl();
	}
}
