package com.cts.fse.feedback.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cts.fse.feedback.bean.EventFeedbackResponse;
import com.cts.fse.feedback.bean.EventFeedbackResponseIdentity;

@Repository
public interface EventFeedbackResponseRepository extends CrudRepository<EventFeedbackResponse, 
EventFeedbackResponseIdentity>
{
	
}
