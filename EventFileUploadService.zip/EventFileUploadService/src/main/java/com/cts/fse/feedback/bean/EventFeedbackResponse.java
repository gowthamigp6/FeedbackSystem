package com.cts.fse.feedback.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class EventFeedbackResponse implements Serializable {
	
	@EmbeddedId
	private EventFeedbackResponseIdentity eventFeedbackResponseIdentity;
	
   
    private String feedbackResponse;
    private Date emailSendDate;
    private String status;

	public String getFeedbackResponse() {
		return feedbackResponse;
	}
	public void setFeedbackResponse(String feedbackResponse) {
		this.feedbackResponse = feedbackResponse;
	}
	public Date getEmailSendDate() {
		return emailSendDate;
	}
	public void setEmailSendDate(Date emailSendDate) {
		this.emailSendDate = emailSendDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
    
    
}
