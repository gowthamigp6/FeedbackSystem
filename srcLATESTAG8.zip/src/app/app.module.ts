import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import {HttpClient, HttpRequest, HttpEvent} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from "@angular/router";
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { NavigationComponent } from './navigation/navigation.component';
import { UploadFileService } from './service/file-upload.service';
import { UserRoleComponent } from './user-role/user-role.component';
import { AddUserComponent } from './add-user/add-user.component';
import { MatTabsModule,MatDialog } from '@angular/material';
import { CdkTableModule} from '@angular/cdk/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule,MatIconModule,MatSortModule,MatPaginatorModule,MatDialogModule,
  MatFormFieldModule, MatInputModule,MatSelectModule} from '@angular/material';
import { ViewUserComponent } from './view-user/view-User.component';
import { FeedbackResponseComponent } from './feedback-response/feedback-response.component';
import { SendEmailComponent } from './send-email/send-email.component';
import {UserRoleService } from './service/user-role.service';
import {FeedBackService } from './service/feedback-details.service';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ViewFeedbackComponent } from './feedback/view-feedback/view-feedback.component';
import { FeedbackDetailsComponent } from './feedback/feedback-details/feedback-details.component';
import { AddFeedbackComponent } from './feedback/add-feedback/add-feedback.component';
import { EditFeedbackComponent } from './feedback/edit-feedback/edit-feedback.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    FooterComponent,
    FileUploadComponent,
    NavigationComponent,
    UserRoleComponent,
    AddUserComponent,
    ViewUserComponent,
    FeedbackResponseComponent,
    SendEmailComponent,
    EditUserComponent,
    ViewFeedbackComponent,
    FeedbackDetailsComponent,
    AddFeedbackComponent,
    EditFeedbackComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule,
    MatTabsModule,
    CdkTableModule,
    MatTableModule,
    MatIconModule,
    MatSortModule,
    BrowserAnimationsModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatDialogModule,
    MatSelectModule,
    MatInputModule,
    HttpClientModule
  ],
  entryComponents: [EditUserComponent,EditFeedbackComponent],
  providers: [UploadFileService,UserRoleService,FeedBackService],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { }
