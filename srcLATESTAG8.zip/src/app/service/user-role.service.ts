import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
  //import {map} from 'rxjs/add/operator/map';
import { User } from '../model/user.model';
import { of } from 'rxjs/observable/of';
 import { catchError, map, tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserRoleService {

  private userUrl = window["apiBaseUrl"]+"userDetails";

  constructor(private http: HttpClient) { }

  getUsers(): Observable<User[]>{
	return this.http.get<User[]>(this.userUrl+"/get");
  }

     /** POST: add a new user to the server */
 addUser (user: User) : Observable<User> {
  const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});
  return this.http.post<User>(this.userUrl+"/create", JSON.stringify(user), {headers: headers});
 
}

deleteUser (associateId: number) {
  return this.http.delete(this.userUrl+"/"+ associateId);
}


updateUser(user : User){
    const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});

    this.http.put(this.userUrl+"/update", JSON.stringify(user), {headers: headers}).subscribe(() => user);
}

validateLogin(assoicateId : number) : Observable<Object>{
  return this.http.get<Object>(this.userUrl+"/getLoginUser/"+assoicateId,httpOptions);


}

 validateEventUser(assoicateId : number) : Observable<String>{
  
  return this.http.get<String>(this.userUrl+"/eventfeedbackResponse"+assoicateId);
 }

}
