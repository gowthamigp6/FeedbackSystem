export class User{

    associateId: number;
	associateName: string;
	role: string; 
	eventId:string;
}