import { Component, OnInit,ViewChild } from '@angular/core';
import {FeedBackDetails} from '../../model/feedback.model';
import {FeedBackService } from '../../service/feedback-details.service';
import {MatPaginator, MatTableDataSource,MatDialog ,MatSort } from '@angular/material';
import { EditFeedbackComponent } from '../edit-feedback/edit-feedback.component';

@Component({
  selector: 'app-view-feedback',
  templateUrl: './view-feedback.component.html',
  styleUrls: ['./view-feedback.component.css']
})
export class ViewFeedbackComponent implements OnInit {

  displayedColumns: string[] = ['id','status','feedBackDesc', 'emailTemplate','inputType','Edit','delete'];
  dataSource = new MatTableDataSource<FeedBackDetails>();
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private feedBackService: FeedBackService,private dialog: MatDialog) { 
    var data = sessionStorage.getItem('id');
    console.log(data);
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getList();
  }
  public getList = () => {
    this.feedBackService.get()
    .subscribe(feedback => {
      this.dataSource.data = feedback as FeedBackDetails[];
    })
  }

  
  redirectToEdit = (feedback: FeedBackDetails) => {
    this.getList();
  }

  redirectToDelete = (id: number) => {
    this.feedBackService.delete(id);
    this.loadData();
  }

   loadData() {
    this.dataSource = new MatTableDataSource<FeedBackDetails>();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getList();
    
  }

 

  startEdit(i:number,id: number, status: String, feedBackDesc: string, emailTemplate: string) {
    console.log("user"+id);
      const dialogRef = this.dialog.open(EditFeedbackComponent, {
      data: {id:id, status:status, feedBackDesc:feedBackDesc,emailTemplate:emailTemplate}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("inside");
        this.loadData();
    });
  }
}
