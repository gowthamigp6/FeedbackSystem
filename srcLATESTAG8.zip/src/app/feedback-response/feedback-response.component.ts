import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import {FeedBackService } from '../service/feedback-details.service';
import {FeedBackDetails} from '../model/feedback.model';

@Component({
  selector: 'app-feedback-response',
  templateUrl: './feedback-response.component.html',
  styleUrls: ['./feedback-response.component.css']
})
export class FeedbackResponseComponent implements OnInit {

  feedbackResponseForm: FormGroup;
  feedbackDetails: FeedBackDetails[]=[];
  constructor( private formBuilder: FormBuilder,private feedBackService: FeedBackService) { 
    var data = sessionStorage.getItem('id');
    console.log(data);
    
  }

  ngOnInit() {
    this.getList();
    this.feedbackResponseForm = this.formBuilder.group({
      feedbackResponse: ['', Validators.required],
      smileyValue: ['', Validators.required],
      selected: ['', Validators.required]
    });
  }


  public getList = () => {
    var eventStatus = sessionStorage.getItem('eventStatus');
    console.log("gjhg"+eventStatus);
    this.feedBackService.getFeedbackDetails(eventStatus)
    .subscribe(feedback => {
      this.feedbackDetails = feedback as FeedBackDetails[];
    })
  }

  radioChecked(id, i){
    this.feedbackDetails.forEach(item=>{
      if(item.id !== id){ 
         item.selected = false;
      }else{
         item.selected = true;
      } 
    })
  }

  onSubmit( feedbackDetails: FeedBackDetails[]){
    console.log(feedbackDetails);
    var eventStatus = sessionStorage.getItem('id');
    console.log("gjhg"+eventStatus);
    this.feedBackService.saveEventResponse(feedbackDetails,eventStatus);
  }

}