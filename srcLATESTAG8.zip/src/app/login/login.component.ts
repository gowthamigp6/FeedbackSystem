import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule,ReactiveFormsModule, FormGroup,FormBuilder, Validators } from '@angular/forms';
import { Identifiers } from '@angular/compiler';
import {UserRoleService } from '../service/user-role.service';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';
// import {map} from 'rxjs/add/operator/map';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  invalidLogin = false;
  users: User[]=[];
  status="";
  associateId : number;
  private user : Observable<Object>;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private formModule : FormsModule,
    private router: Router,
    private userService: UserRoleService
  ) { }

  

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
        userName: ['', Validators.required],
        password: ['', Validators.required]
    });
  }

  onSubmit() {
   
    this.submitted = true;

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }else{
          if(this.loginForm.controls.userName.value == this.loginForm.controls.password.value) {
           
            this.user= this.userService.validateLogin(this.loginForm.controls.userName.value);
            let jsonAsText = JSON.stringify(this.user);
            // .map((user:User)=>user as User);
            // .subscribe( res => { 
            //   this.user=res;
              
            // })
           
              console.log("user"+this.user+jsonAsText);
            //  console.log("user"+this.user);
            //  console.log("associateId"+this.users.associateId);
            // console.log("user"+this.user.associateId);
            sessionStorage.setItem('id', this.loginForm.controls.userName.value);
            sessionStorage.setItem('role', "Admin");
             sessionStorage.setItem('eventStatus', "Participated");
            //sessionStorage.setItem('eventStatus', "UnRegistered");
            this.router.navigate(['/header']);
          }else{
            this.invalidLogin = true;
          }
         
        }
        // if(this.loginForm.controls.userName.value == '552350' && 
        //     this.loginForm.controls.password.value == '552350') {
        //   const id=this.loginForm.controls.userName.value;
        //   sessionStorage.setItem('associateId', id);
        //   sessionStorage.setItem('eventId', id);
        //   sessionStorage.setItem('role', id);
        //   this.router.navigate(['/header']);
        // }else{
        //   this.invalidLogin = true;
        // }
  }

 
}
