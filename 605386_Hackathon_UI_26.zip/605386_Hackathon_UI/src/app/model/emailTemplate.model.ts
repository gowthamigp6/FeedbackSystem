export interface EmailTemplate{

    status: number;
	emailTemplate: string;
    emailNotification: number; 
    notificationInterval:number;
    isEditable:boolean;
}