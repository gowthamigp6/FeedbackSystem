export interface EventEmployeeInfo{

    associateId: number;
	eventId: string;
	eventStatus: string; 
}