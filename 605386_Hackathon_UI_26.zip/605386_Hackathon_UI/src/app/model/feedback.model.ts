export interface FeedBackDetails{
    id: number;
	feedBackDesc: string;
	status: string; 
	inputType:string;
	selected:boolean;
	feedbackResponse:String;
	smileyValue:string;
}