export class User{

    associateId: number;
	associateName: string;
	role: string; 
	eventId:string;
	token?: string;
}