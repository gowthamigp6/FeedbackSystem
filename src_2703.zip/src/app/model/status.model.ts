export interface EventStatusCount{
    eventId : String;
    registered : number;
    unRegistered : number;
    notAttended : number;  
}