export interface ResponseSummaryDTO{
    event: string;
    feedbackResponse: string;
    status:string; 
}