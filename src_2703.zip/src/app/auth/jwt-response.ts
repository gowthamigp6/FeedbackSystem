export class JwtResponse {
    accessToken: string;
    type: string;
    username: string;
    role:string;
    eventId:string;
    eventStatus:string;
    associateId:string;
	responded:string;
}
