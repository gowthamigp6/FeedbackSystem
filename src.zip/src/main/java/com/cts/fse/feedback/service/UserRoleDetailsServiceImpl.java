package com.cts.fse.feedback.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.fse.feedback.bean.UserRoleDetails;
import com.cts.fse.feedback.repository.UserRoleDetailsRepository;


@Service
@Transactional
public class UserRoleDetailsServiceImpl implements UserRoleDetailsService {

	@Autowired
	private UserRoleDetailsRepository  userRoleDetailsRepository;

	@Override
	public UserRoleDetails createUser(UserRoleDetails user) {
		// TODO Auto-generated method stub
		return userRoleDetailsRepository.save(user);
	}

	@Override
	public List<UserRoleDetails> getUser() {
		// TODO Auto-generated method stub
		return (List<UserRoleDetails>) userRoleDetailsRepository.findAll();
	}

	@Override
	public UserRoleDetails findById(Integer associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserRoleDetails update(UserRoleDetails user, Integer associateId) {
		// TODO Auto-generated method stub
		return userRoleDetailsRepository.save(user);
	}

	@Override
	public void deleteUserById(Integer associateId) {
		// TODO Auto-generated method stub
		
	}
}
