package com.cts.ddd.domain.user;

import javax.persistence.Embeddable;
import org.apache.commons.lang.builder.EqualsBuilder;
import com.cts.ddd.domain.shared.ValueObject;


@Embeddable
public class Address implements ValueObject<Address> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String streetName;
	private String doorNo;
	private String plotNo;
	private String city;
	private String pinCode;
	
	

	@Override
	public boolean sameValueAs(Address other) {
		// TODO Auto-generated method stub
		return other != null && new EqualsBuilder().
			      append(this.streetName, other.streetName).
			      append(this.doorNo, other.doorNo).
			      append(this.plotNo, other.plotNo).
			      append(this.city, other.city).
			      append(this.pinCode, other.pinCode).
			      isEquals();
	}
}
