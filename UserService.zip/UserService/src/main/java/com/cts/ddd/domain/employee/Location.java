package com.cts.ddd.domain.employee;


import javax.persistence.Embeddable;
import org.apache.commons.lang.builder.EqualsBuilder;
import com.cts.ddd.domain.shared.ValueObject;


@Embeddable
public class Location implements ValueObject<Location> {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String fromLocation;
	    
	 private String toLocation;

	@Override
	public boolean sameValueAs(Location other) {
		 return other != null && new EqualsBuilder().
			      append(this.fromLocation, other.fromLocation).
			      append(this.toLocation, other.toLocation).
			      isEquals();
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}
	
	
}
