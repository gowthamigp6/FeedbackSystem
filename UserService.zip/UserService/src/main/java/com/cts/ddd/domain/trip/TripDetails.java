package com.cts.ddd.domain.trip;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import com.cts.ddd.domain.employee.EmployeeRegistration;
import com.cts.ddd.domain.user.User;



@Entity
public class TripDetails {


	@EmbeddedId
    private TripDetailsIdentity tripDetailsIdentity;
    
	@Embedded
	private TravelDetails travelDetails;
    
    @OneToOne
    @JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
    insertable=false,updatable=false)})
    private User user;
    
    @OneToOne
    @JoinColumns({@JoinColumn(name="vehicleNo",referencedColumnName="vehicleNo",
    insertable=false,updatable=false)})
    private EmployeeRegistration employeeRegistration;

	public TripDetailsIdentity getTripDetailsIdentity() {
		return tripDetailsIdentity;
	}

	public void setTripDetailsIdentity(TripDetailsIdentity tripDetailsIdentity) {
		this.tripDetailsIdentity = tripDetailsIdentity;
	}

	public TravelDetails getTravelDetails() {
		return travelDetails;
	}

	public void setTravelDetails(TravelDetails travelDetails) {
		this.travelDetails = travelDetails;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public EmployeeRegistration getEmployeeRegistration() {
		return employeeRegistration;
	}

	public void setEmployeeRegistration(EmployeeRegistration employeeRegistration) {
		this.employeeRegistration = employeeRegistration;
	}
    
    
}
