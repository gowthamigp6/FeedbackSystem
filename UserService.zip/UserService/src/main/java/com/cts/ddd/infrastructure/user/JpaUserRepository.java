package com.cts.ddd.infrastructure.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cts.ddd.domain.user.User;


@Repository
public interface JpaUserRepository extends JpaRepository<User, String>{

}
