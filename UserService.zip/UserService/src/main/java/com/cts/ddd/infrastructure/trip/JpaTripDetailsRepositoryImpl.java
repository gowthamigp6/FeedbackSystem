package com.cts.ddd.infrastructure.trip;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.cts.ddd.domain.trip.TripDetails;
import com.cts.ddd.domain.trip.TripDetailsRepository;

public class JpaTripDetailsRepositoryImpl implements TripDetailsRepository {

	@Autowired
	private JpaTripDetailsRepository jpaTripDetailsRepository;
	
	@Override
	public TripDetails saveTripDetails(TripDetails tripDetails) {
		return jpaTripDetailsRepository.save(tripDetails);
	}

	@Override
	public Iterable<TripDetails> getAllTripDetails() {
		return jpaTripDetailsRepository.findAll();
	}

	@Override
	public List<TripDetails> getCustomerTripDetails(String userId) {
		return jpaTripDetailsRepository.getCustomerTripDetails(userId);
	}

	@Override
	public List<TripDetails> getEmployeeTripDetails(String userId) {
		return jpaTripDetailsRepository.getEmployeeTripDetails(userId);
	}

}
