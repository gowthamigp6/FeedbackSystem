package com.cts.ddd.domain.user;

import java.util.List;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import com.cts.ddd.domain.employee.EmployeeRegistration;
import com.cts.ddd.domain.trip.TripDetails;



@Entity
public class User {

	@Id
	private String userId;
	private String password;
	private String role;
	
	@Embedded
	private FullName fullName;
	
	@Embedded
	private ContactInformation contactInformation;
	
	@Embedded
	private Address address;
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="vehicleNo",referencedColumnName="vehicleNo",
	    insertable=false,updatable=false)})
	private EmployeeRegistration employeeRegistration;
	
	@OneToMany
	@JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
	    insertable=false,updatable=false)})
	private List<TripDetails> tripDetails;

	public User() {
		super();
	}

	public User(String userId, String password, String role, FullName fullName, ContactInformation contactInformation,
			Address address) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.fullName = fullName;
		this.contactInformation = contactInformation;
		this.address = address;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public FullName getFullName() {
		return fullName;
	}

	public void setFullName(FullName fullName) {
		this.fullName = fullName;
	}

	public ContactInformation getContactInformation() {
		return contactInformation;
	}

	public void setContactInformation(ContactInformation contactInformation) {
		this.contactInformation = contactInformation;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	

	
	
}
