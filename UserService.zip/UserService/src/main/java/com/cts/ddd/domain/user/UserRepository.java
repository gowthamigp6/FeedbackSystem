package com.cts.ddd.domain.user;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserRepository extends UserDetailsService {

	User findUserId(String userId);
	
	User addUser(User user);
	
	void deleteUser(String userId);
	
	Iterable<User> getAllUser();
	
}