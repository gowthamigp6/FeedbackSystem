package com.cts.ddd.domain.user;

import javax.persistence.Embeddable;
import org.apache.commons.lang.builder.EqualsBuilder;
import com.cts.ddd.domain.shared.ValueObject;



@Embeddable
public class ContactInformation implements ValueObject<ContactInformation> {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailId;
	private String telephoneNo;

	@Override
	public boolean sameValueAs(ContactInformation other) {
		// TODO Auto-generated method stub
		 return other != null && new EqualsBuilder().
			      append(this.emailId, other.emailId).
			      append(this.telephoneNo, other.telephoneNo).
			      isEquals();
	}
	
}
