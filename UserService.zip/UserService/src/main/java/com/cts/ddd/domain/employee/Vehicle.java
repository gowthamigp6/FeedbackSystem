package com.cts.ddd.domain.employee;

import java.math.BigDecimal;
import javax.persistence.Embeddable;
import org.apache.commons.lang.builder.EqualsBuilder;
import com.cts.ddd.domain.shared.ValueObject;


@Embeddable
public class Vehicle implements ValueObject<Vehicle> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    private String vehicleType;

    private Integer seater;
    
    private BigDecimal travelCost;

	@Override
	public boolean sameValueAs(Vehicle other) {
		 return other != null && new EqualsBuilder().
			      append(this.vehicleType, other.vehicleType).
			      append(this.seater, other.seater).
			      append(this.travelCost, other.travelCost).
			      isEquals();
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public Integer getSeater() {
		return seater;
	}

	public void setSeater(Integer seater) {
		this.seater = seater;
	}

	public BigDecimal getTravelCost() {
		return travelCost;
	}

	public void setTravelCost(BigDecimal travelCost) {
		this.travelCost = travelCost;
	}
	
	
}
