package com.cts.ddd.infrastructure.trip;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ddd.domain.trip.TripDetails;

@Repository
public interface JpaTripDetailsRepository extends JpaRepository<TripDetails, String> {

	@Query("from TripDetails trip where trip.user.userId=:userId")
	List<TripDetails> getCustomerTripDetails(@Param("userId") String userId);
	
	@Query("from TripDetails trip where trip.employeeRegistration.user.userId=:userId")
	List<TripDetails> getEmployeeTripDetails(@Param("userId") String userId);
}
