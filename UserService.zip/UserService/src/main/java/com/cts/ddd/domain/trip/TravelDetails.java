package com.cts.ddd.domain.trip;

import java.sql.Date;
import javax.persistence.Embeddable;
import org.apache.commons.lang.builder.EqualsBuilder;

import com.cts.ddd.domain.shared.ValueObject;


@Embeddable
public class TravelDetails implements ValueObject<TravelDetails> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String travelTime;
    
    

    private String travelStatus;
    
	@Override
	public boolean sameValueAs(TravelDetails other) {
		 return other != null && new EqualsBuilder().
			      append(this.travelTime, other.travelTime).
			      append(this.travelStatus, other.travelStatus).
			      isEquals();
	}

	public String getTravelTime() {
		return travelTime;
	}

	public void setTravelTime(String travelTime) {
		this.travelTime = travelTime;
	}

	public String getTravelStatus() {
		return travelStatus;
	}

	public void setTravelStatus(String travelStatus) {
		this.travelStatus = travelStatus;
	}
	
	
}
