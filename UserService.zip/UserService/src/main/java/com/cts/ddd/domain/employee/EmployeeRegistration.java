package com.cts.ddd.domain.employee;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

import com.cts.ddd.domain.user.User;


@Entity
public class EmployeeRegistration {

	@Id
	private String vehicleNo;

	@Embedded
    private Location location;
	
	@Embedded
    private Vehicle vehicle;
    
    
	@OneToOne
	@JoinColumns({@JoinColumn(name="userId",referencedColumnName="userId",
    insertable=false,updatable=false)})
	private User user;


	public String getVehicleNo() {
		return vehicleNo;
	}


	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}


	public Location getLocation() {
		return location;
	}


	public void setLocation(Location location) {
		this.location = location;
	}


	public Vehicle getVehicle() {
		return vehicle;
	}


	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}

    
}