package com.cts.fse.feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventFileUploadServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventFileUploadServiceApplication.class, args);
	}
	
	
}
