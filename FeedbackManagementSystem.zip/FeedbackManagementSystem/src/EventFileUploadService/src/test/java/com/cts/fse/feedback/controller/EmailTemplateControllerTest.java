package com.cts.fse.feedback.controller;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.cts.fse.feedback.bean.EmailTemplate;
import com.cts.fse.feedback.service.EmailTemplateService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@RunWith(SpringRunner.class)
@WebMvcTest(value=EventFileUploadController.class,secure = false)
public class EmailTemplateControllerTest {
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmailTemplateService emailTemplateService;
	
	@Test
	public void testGetTemplateList() throws Exception{
		
		EmailTemplate mockEmailTemplate =new EmailTemplate();
		mockEmailTemplate.setStatus("PARTICIPATED");
		mockEmailTemplate.setEmailTemplate("Body of the content");
		mockEmailTemplate.setEmailNotification(1);
		mockEmailTemplate.setNotificationInterval(2);
	
		
		List<EmailTemplate> emailTemplateList = new ArrayList<EmailTemplate>();
		emailTemplateList.add(mockEmailTemplate);
		
		
		Mockito.when(emailTemplateService.get()).thenReturn(emailTemplateList);
		
		String URI = "/emailTemplate/get";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				URI).accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		String expectedJson = this.mapToJson(emailTemplateList);
		String outputInJson = result.getResponse().getContentAsString();
		assertThat(outputInJson).isEqualTo(expectedJson);
	}
	
	

	@Test
	public void testUpdate() throws Exception {
		
		EmailTemplate mockEmailTemplate =new EmailTemplate();
		mockEmailTemplate.setStatus("PARTICIPATED");
		mockEmailTemplate.setEmailTemplate("Body of the content");
		mockEmailTemplate.setEmailNotification(1);
		mockEmailTemplate.setNotificationInterval(2);
	
		
		String inputInJson = this.mapToJson(mockEmailTemplate);
		
		String URI = "/emailTemplate/update";
		
		Mockito.when(emailTemplateService.update(Mockito.any(EmailTemplate.class))).thenReturn(mockEmailTemplate);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.put(URI).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(inputInJson);
				

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		String outputInJson = response.getContentAsString();
		
		assertThat(outputInJson).isEqualTo(inputInJson);
		//assertEquals(HttpStatus.OK, response.getStatus());
	
	}	
	
//	@Test
//	public void testSendEmailToAssociates() throws Exception {
//
//		EventEmployeeInfoDTO eventEmployeeInfoDTO =new EventEmployeeInfoDTO();
//		eventEmployeeInfoDTO.setEventId("EventID7541");
//		eventEmployeeInfoDTO.set("Body of the content");
//		eventEmployeeInfoDTO.setEmailNotification(1);
//		mockEmailTemplate.setNotificationInterval(2);
//	
//		
//		String inputInJson = this.mapToJson(mockEmailTemplate);
//		
//		String URI = "/emailTemplate/update";
//		
//		Mockito.when(emailTemplateService.update(Mockito.any(EmailTemplate.class))).thenReturn(mockEmailTemplate);
//		
//		RequestBuilder requestBuilder = MockMvcRequestBuilders
//				.put(URI).contentType(MediaType.APPLICATION_JSON)
//				.accept(MediaType.APPLICATION_JSON).content(inputInJson);
//				
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//		MockHttpServletResponse response = result.getResponse();
//		
//		String outputInJson = response.getContentAsString();
//		
//		assertThat(outputInJson).isEqualTo(inputInJson);
//	}
	
	
	
	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}
	
}

