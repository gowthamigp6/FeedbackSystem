package com.cts.fse.feedback.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.fse.feedback.bean.FeedbackDetails;
import com.cts.fse.feedback.repository.FeedbackDetailsRepository;

@Service
@Transactional
public class FeedBackDetailsServiceImpl implements FeedBackDetaillsService{

	@Autowired
	private FeedbackDetailsRepository  feedbackDetailsRepository;
	
	
	@Override
	public FeedbackDetails createFeedBackQuestion(FeedbackDetails feedbackDetails) {
		return feedbackDetailsRepository.save(feedbackDetails);
	}

	@Override
	public Iterable<FeedbackDetails> getFeedBackDetails() {
		return feedbackDetailsRepository.findAll();
	}

	@Override
	public FeedbackDetails update(FeedbackDetails feedbackDetails) {
		return feedbackDetailsRepository.save(feedbackDetails);
	}

	@Override
	public void deleteFeedBack(Integer id) {
		feedbackDetailsRepository.deleteById(id);
	}

	@Override
	public Iterable<FeedbackDetails> getFeedBackQuestion(String eventStatus) {
		return feedbackDetailsRepository.getFeedbackList(eventStatus);
	}

	
}
