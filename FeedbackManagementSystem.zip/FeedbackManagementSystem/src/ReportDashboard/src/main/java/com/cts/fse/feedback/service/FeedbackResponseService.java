package com.cts.fse.feedback.service;

import java.util.List;

import com.cts.fse.feedback.bean.DashboardReportDTO;
import com.cts.fse.feedback.bean.EventResponseDTO;

public interface FeedbackResponseService {

  public void saveEventFeedBackResponse(List<EventResponseDTO> responseDetails,String eventId,int associateId);
  
  List<DashboardReportDTO> getSmileyReport();
	
}
