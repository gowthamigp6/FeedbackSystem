package com.cts.fse.feedback.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.fse.feedback.bean.UserRoleDetails;
import com.cts.fse.feedback.service.UserRoleDetailsService;



@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
@Controller
@RequestMapping(value={"/userDetails"})
public class UserRoleDetailsController {

	@Autowired
	private UserRoleDetailsService userRoleDetailsService;
	
    @GetMapping(value = "getLoginUser/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserRoleDetails> getUserById(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        UserRoleDetails user = userRoleDetailsService.findById(id);
        System.out.println("Fetching User with id " + user);
        if (user == null) {
            return new ResponseEntity<UserRoleDetails>(HttpStatus.NOT_FOUND);
        }
        return  ResponseEntity.ok().body(user);
    }
    
    @PostMapping(value="/create")
	 public ResponseEntity<String>  createUser(@RequestBody UserRoleDetails user){
    	 userRoleDetailsService.createUser(user);	
    	return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	 }
 
	 @GetMapping(value="/get", headers="Accept=application/json")
	 public @ResponseBody Iterable<UserRoleDetails> getAllUser() {	 
	  return userRoleDetailsService.getUser();
	 }

	@PutMapping(value="/update")
	public ResponseEntity<String> updateUser(@RequestBody UserRoleDetails currentUser) {
		userRoleDetailsService.update(currentUser);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
	public ResponseEntity<UserRoleDetails> deleteUser(@PathVariable("id") Integer id){
		userRoleDetailsService.deleteUser(id);
		return new ResponseEntity<UserRoleDetails>(HttpStatus.NO_CONTENT);
	}
	
}