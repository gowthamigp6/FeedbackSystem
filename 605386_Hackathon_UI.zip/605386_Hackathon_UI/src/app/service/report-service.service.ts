import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpRequest } from '@angular/common/http';
import { EventSummaryDetails } from '../model/report.model';
import { EventStatusCount } from '../model/status.model';
import { Observable } from 'rxjs'; 
import { Dashboard } from '../model/dahboard.model';

@Injectable()
export class ReportServiceService {

  private dasboardUrl =window["apiBaseUrl"]+"dashboard";
  private eventUrl =window["apiBaseUrl"]+"eventFileUpload";

  constructor(private http: HttpClient) {}

  fetchReport() :Observable<Dashboard[]>{
    return this.http.get<Dashboard[]>(this.dasboardUrl+"/getReport");
  }

  getEventDashboardReport() :Observable<Dashboard[]>{
    return this.http.get<Dashboard[]>(this.eventUrl+"/getDashboardReport");
  }
}
