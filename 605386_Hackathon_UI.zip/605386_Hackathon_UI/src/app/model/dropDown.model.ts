export interface DropDown{

    eventId: string;
}