export interface Dashboard{

    eventId: string;
    participatedCount:number;
    notAttendedCount:number;
    unRegisteredCount:number;
    averageSmileyCount:any;
}