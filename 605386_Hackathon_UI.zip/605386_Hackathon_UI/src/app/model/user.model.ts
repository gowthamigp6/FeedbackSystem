export class User{

    associateId: number;
	associateName: string;
	role: string; 
	eventId:string;
	token?: string;

	constructor(associateId: number, associateName: string,role:string) {
        this.associateId = associateId;
		this.associateName = associateName;
		this.role = role;
    }
}