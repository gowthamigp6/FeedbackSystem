export class FeedBackDetails{
    id: number;
	feedBackDesc: string;
	status: string; 
	inputType:string;
	selected:boolean;
	feedbackResponse:String;
	smileyValue:string;
	constructor(status: string, feedBackDesc: string,inputType:string) {
        this.feedBackDesc = feedBackDesc;
		this.inputType = inputType;
		this.status = status;
    }
}