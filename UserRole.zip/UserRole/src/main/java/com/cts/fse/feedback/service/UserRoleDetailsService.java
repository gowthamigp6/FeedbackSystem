package com.cts.fse.feedback.service;

import java.util.List;

import com.cts.fse.feedback.bean.UserRoleDetails;

public interface UserRoleDetailsService {

	public UserRoleDetails createUser(UserRoleDetails user);
	public Iterable<UserRoleDetails> getUser();
	public UserRoleDetails findById(Integer associateId);
	public UserRoleDetails update(UserRoleDetails user, Integer associateId);
	public void deleteUser(Integer id);
	
}
