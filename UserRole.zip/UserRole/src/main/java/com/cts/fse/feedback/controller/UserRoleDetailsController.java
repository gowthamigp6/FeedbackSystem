package com.cts.fse.feedback.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.util.UriComponentsBuilder;

import com.cts.fse.feedback.bean.UserRoleDetails;
import com.cts.fse.feedback.service.UserRoleDetailsService;



@Controller
@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
@RequestMapping(value={"/userDetails"})
public class UserRoleDetailsController {

	@Autowired
	private UserRoleDetailsService userRoleDetailsService;
	
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserRoleDetails> getUserById(@PathVariable("id") Integer associateId) {
        System.out.println("Fetching User with id " + associateId);
        UserRoleDetails user = userRoleDetailsService.findById(associateId);
        if (user == null) {
            return new ResponseEntity<UserRoleDetails>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<UserRoleDetails>(user, HttpStatus.OK);
    }
    
    @PostMapping(value="/create",produces = MediaType.APPLICATION_JSON_VALUE)
	 public @ResponseStatus(HttpStatus.CREATED) UserRoleDetails createUser(@RequestBody UserRoleDetails user){
    	
    	
    	return	 userRoleDetailsService.createUser(user);
    		
	 }
    
	/* @PostMapping(value="/create",produces = MediaType.APPLICATION_JSON_VALUE)
	 public UserRoleDetails createUser(@RequestBody UserRoleDetails user){
	     System.out.println("Creating User "+user.getAssociateId());
	     return userRoleDetailsService.createUser(user);
	 }
*/
	 @GetMapping(value="/get", headers="Accept=application/json")
	 public @ResponseBody Iterable<UserRoleDetails> getAllUser() {	 
	  return userRoleDetailsService.getUser();
	 }

	@PutMapping(value="/update", headers="Accept=application/json")
	public ResponseEntity<String> updateUser(@RequestBody UserRoleDetails currentUser) {
		System.out.println("sd");
		UserRoleDetails user = userRoleDetailsService.findById(currentUser.getAssociateId());
		if (user==null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		userRoleDetailsService.update(currentUser, currentUser.getAssociateId());
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin",origins="http://localhost:4200")
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
	public ResponseEntity<UserRoleDetails> deleteUser(@PathVariable("id") Integer id){
		/*UserRoleDetails user = userRoleDetailsService.findById(id);
		if (user == null) {
			return new ResponseEntity<UserRoleDetails>(HttpStatus.NOT_FOUND);
		}*/
		userRoleDetailsService.deleteUser(id);
		return new ResponseEntity<UserRoleDetails>(HttpStatus.NO_CONTENT);
	}
	
}