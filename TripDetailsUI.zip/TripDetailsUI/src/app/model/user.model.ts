export class User{

	username: string;
	role: string; 
	token?: string;
}